import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import classification_report, mean_absolute_error, root_mean_squared_error
from sklearn.model_selection import train_test_split, GridSearchCV
import m2cgen as m2c
import os

DATA_PATH = "data/interpolated_wifi_data_4_neighbours.csv"
os.makedirs("models", exist_ok=True)

# ========== MODEL TRAINING ==========

def train_model(X_train, y_train, model, param_grid, scoring):
    grid = GridSearchCV(model, param_grid, cv=5, scoring=scoring, n_jobs=-1)
    grid.fit(X_train, y_train)
    return grid.best_estimator_

# ========== EVALUATION FUNCTIONS ==========

def evaluate_classifier(model, X_test, y_test):
    y_pred = model.predict(X_test)
    print("=== CLASSIFICATION REPORT ===")
    print(classification_report(y_test, y_pred))

def evaluate_regressor(model, X_test, y_test):
    y_pred = model.predict(X_test)
    rmse = root_mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    print(f"=== REGRESSION METRICS ===")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")

# ========== CODE EXPORT ==========

def export_model_to_java(model, filename):
    java_code = m2c.export_to_java(model)
    with open(filename, "w") as f:
        f.write(java_code)
    print(f"Model exported to {filename}")

# ========== REGRESSION PIPELINE ==========

def run_regression_pipeline(df, target_column, prefix):
    interpolated_data = df[df['phoneId'] == 4]
    original_data = df[df['phoneId'] != 4]
    train_data, test_data = train_test_split(original_data, test_size=0.2, random_state=42)
    train_data = pd.concat([train_data, interpolated_data], ignore_index=True).sample(frac=1, random_state=42)

    X_train = train_data.drop(["x", "y", "phoneId", "timestamp"], axis=1).astype(int)
    y_train = train_data[target_column]
    X_test = test_data.drop(["x", "y", "phoneId", "timestamp"], axis=1).astype(int)
    y_test = test_data[target_column]

    rf_reg = RandomForestRegressor(random_state=42)
    param_grid = {
        "n_estimators": [100],
        "max_depth": [12]
    }

    model = train_model(X_train, y_train, rf_reg, param_grid, scoring="neg_mean_squared_error")
    evaluate_regressor(model, X_test, y_test)
    export_model_to_java(model, f"models/{prefix}Regressor.java")

# ========== MAIN ==========

def main():
    df = pd.read_csv(DATA_PATH)
    run_regression_pipeline(df, target_column="x", prefix="X")
    run_regression_pipeline(df, target_column="y", prefix="Y")

if __name__ == "__main__":
    main()
