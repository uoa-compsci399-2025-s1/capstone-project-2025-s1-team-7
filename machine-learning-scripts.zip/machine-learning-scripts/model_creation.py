import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report, mean_absolute_error, root_mean_squared_error
import m2cgen as m2c
import os


def load_data(file_path: str):
    return pd.read_csv(file_path)


def split_features_targets(df, target_col, drop_cols):
    X = df.drop(columns=drop_cols)
    y = df[target_col]
    return train_test_split(X, y, test_size=0.2, random_state=42)


def train_model(model, param_grid, X_train, y_train, scoring):
    grid = GridSearchCV(model, param_grid, cv=5, scoring=scoring, n_jobs=-1)
    grid.fit(X_train, y_train)
    return grid.best_estimator_


def evaluate_classifier(model, X_test, y_test):
    y_pred = model.predict(X_test)
    print("=== Classification Report ===")
    print(classification_report(y_test, y_pred))


def evaluate_regressor(model, X_test, y_test):
    y_pred = model.predict(X_test)
    rmse = root_mean_squared_error(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    print("=== Regression Evaluation ===")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")


def export_model_to_java(model, filename):
    os.makedirs("models", exist_ok=True)
    java_code = m2c.export_to_java(model)
    with open(f"models/{filename}.java", "w") as f:
        f.write(java_code)
    print(f"Model exported to models/{filename}.java")


def train_and_export_classifier(df):
    drop_cols = ["x", "y", "phoneId", "timestamp"]
    X_train, X_test, y_train, y_test = split_features_targets(df, "floor", drop_cols)

    model = RandomForestClassifier(random_state=42)
    param_grid = {"n_estimators": [100, 200], "max_depth": [None, 10]}
    best_model = train_model(model, param_grid, X_train, y_train, scoring='accuracy')

    evaluate_classifier(best_model, X_test, y_test)
    export_model_to_java(best_model, "FloorClassifier")


def train_and_export_regressor(df, target, name):
    drop_cols = ["x", "y", "phoneId", "timestamp"]
    X_train, X_test, y_train, y_test = split_features_targets(df, target, drop_cols)

    model = RandomForestRegressor(random_state=42)
    param_grid = {"n_estimators": [100, 200], "max_depth": [None, 10]}
    best_model = train_model(model, param_grid, X_train, y_train, scoring='neg_mean_squared_error')

    evaluate_regressor(best_model, X_test, y_test)
    export_model_to_java(best_model, f"{name}Regressor")


def main():
    df = load_data("data/edited_v1.csv")

    print("\n--- Floor Classifier ---")
    train_and_export_classifier(df)

    print("\n--- X Regressor ---")
    train_and_export_regressor(df, target="x", name="X")

    print("\n--- Y Regressor ---")
    train_and_export_regressor(df, target="y", name="Y")


if __name__ == "__main__":
    main()
